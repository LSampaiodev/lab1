package com.example.contact_manager

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
